<?php 
define('KOD_VERSION','2.2');//2014.4.2