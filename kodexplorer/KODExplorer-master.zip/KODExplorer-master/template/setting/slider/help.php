<div class='h1'><i class="font-icon icon-question"></i><?php echo $L['setting_help'];?>
<a class="button" style="margin-left:20px;" href="javascript:FrameCall.father('core.update','\'check\'')">update</a></div>
<div class="section">
	<div class="content">
		<?php include(LANGUAGE_PATH.LANGUAGE_TYPE.'/help.html');?>
	</div>
</div>
