<?php 
define('KOD_VERSION','2.1');//2014.4.2